public class AppAdapter {
}
