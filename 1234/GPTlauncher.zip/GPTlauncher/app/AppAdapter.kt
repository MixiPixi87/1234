class AppAdapter {
    package com.example.mylauncher

    import android.view.LayoutInflater
    import android.view.View
    import android.view.ViewGroup
    import android.widget.TextView
    import androidx.recyclerview.widget.RecyclerView

    class AppAdapter(private val appNames: List<String>) :
        RecyclerView.Adapter<AppAdapter.ViewHolder>() {

        // Create ViewHolder
        class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val textView: TextView = itemView.findViewById(android.R.id.text1)
        }

        // Create ViewHolder
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val context = parent.context
            val inflater = LayoutInflater.from(context)
            val appView = inflater.inflate(android.R.layout.simple_list_item_1, parent, false)
            return ViewHolder(appView)
        }

        // Bind data to ViewHolder
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val appName = appNames[position]
            holder.textView.text = appName
        }

        // Get item count
        override fun getItemCount(): Int {
            return appNames.size
        }
    }

}